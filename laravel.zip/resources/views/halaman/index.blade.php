{{-- Yang dibawah Blade --}}
@extends('layout/aplikasi') 

@section('konten')
    <div class="text-center fs-4">Halaman index</div>
    <p class="text-center mt-3 fs-5"> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam minima doloribus unde consequuntur explicabo culpa nemo minus accusantium reiciendis delectus.</p>
@endsection
    
