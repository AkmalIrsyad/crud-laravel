<?php $__env->startSection('konten'); ?>
<a href="/siswa/create" class="btn btn-primary" class="mb-3">Tambah Data</a>
<div class="mb-3">
    <p class="fst-normal fs-4 text-center">Tampilan CRUD Dalam Bentuk Table </p>
</div>
<table class="table table-striped">
    <thead>
      <tr>
        <th>Foto</th>
        <th>NIK</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td>
            <?php if($item->foto): ?>
            <img style="max-width:50px; max-height:50px" src="<?php echo e(url('foto').'/'.$item->foto); ?>"/>
        <?php endif; ?>
        </td>
        <td><?php echo e($item->nomor_induk); ?></td>
        <td><?php echo e($item->nama); ?></td>
        <td><?php echo e($item->alamat); ?></td>
        
        <td>
        <a href="<?php echo e(url('/siswa/'.$item->nomor_induk)); ?>" class="btn btn-secondary btn-sm">Detail</a>
        <a href="<?php echo e(url('/siswa/'.$item->nomor_induk.'/edit')); ?>" class="btn btn-warning btn-sm">edit</a>
        <form onsubmit="return confirm('Yakin Mau Hapus Data?')" class="d-inline" action="<?php echo e('/siswa/'.$item->nomor_induk); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger btn-sm" type="submit">Delete
            </button>
        </form>
    </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <div class="mb-3">
    <p class="fst-normal fs-4 text-center">Tampilan CRUD Dalam Bentuk Cards </p>
</div>
  <div class="row">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card mb-3" style="max-width: 540px;">
          <div class="row g-0">
            <div class="col-md-4">
              <?php if($item->foto): ?>
                <img src="<?php echo e(url('foto').'/'.$item->foto); ?>" class="img-fluid rounded-start">
              <?php endif; ?>
            </div>
            <div class="col-md-8">
              <div class="card-body shadow">
                <h5 class="card-title"><?php echo e($item->nama); ?></h5>
                <p class="card-text"><?php echo e($item->alamat); ?></p>
                <p class="card-text"><small class="text-body-secondary">NIK by <?php echo e($item->nomor_induk); ?></small></p>
                <div class="">
                    <a href="<?php echo e(url('/siswa/'.$item->nomor_induk)); ?>" class="btn btn-secondary" type="button">Detail</a>
                    <a href="<?php echo e(url('/siswa/'.$item->nomor_induk.'/edit')); ?>" class="btn btn-warning" type="button">Edit</a>
                    <form onsubmit="return confirm('Yakin Mau Hapus Data?')" class="d-inline" action="<?php echo e('/siswa/'.$item->nomor_induk); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views/siswa/index.blade.php ENDPATH**/ ?>