


<?php $__env->startSection('konten'); ?>
<div class="text-center fs-4"><?php echo e($judul); ?></div>
<p class="text-center mt-3 fs-5">Halaman Kontak Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam minima doloribus unde consequuntur explicabo culpa nemo minus accusantium reiciendis delectus.</p>
<p>
  <ul>
    <li>Email:<?php echo e($kontak['email']); ?></li>
    <li>Youtube:<?php echo e($kontak['discord']); ?></li>
  </ul>
</p>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views/halaman/kontak.blade.php ENDPATH**/ ?>