
 

<?php $__env->startSection('konten'); ?>
    <div class="text-center fs-4">Halaman index</div>
    <p class="text-center mt-3 fs-5"> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam minima doloribus unde consequuntur explicabo culpa nemo minus accusantium reiciendis delectus.</p>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views/halaman/index.blade.php ENDPATH**/ ?>