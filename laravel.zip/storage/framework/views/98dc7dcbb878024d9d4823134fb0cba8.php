

<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<?php if(Session::get('success')): ?> <!--menangkap variable success di SiswaController -->
<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div> <!--Dengan isian dari with yang ada di SiswaController -->
<?php endif; ?>
</ul>
<?php /**PATH D:\LARAVEL9\resources\views/komponen/pesan.blade.php ENDPATH**/ ?>