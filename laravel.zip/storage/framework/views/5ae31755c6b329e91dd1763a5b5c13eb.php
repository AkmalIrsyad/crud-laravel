<?php $__env->startSection('konten'); ?>
<form method="POST"action="/siswa">
    
    
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="form-floating mb-3">
            <input type="text" class="form-control" id="NIK" placeholder="NIK" name="nomor_induk" value="<?php echo e(Session::get('nomor_induk')); ?>">
            <label for="NIK">Nomor Induk</label>
          </div>
          <div class="form-floating mb-3 ">
            <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" value="<?php echo e(Session::get('nama')); ?>" >
            <label for="nama">Nama</label>
          </div>
          <div class="mb-3">
            <label for="alamat">Alamat</label>
            <textarea class="form-control" name="alamat" ><?php echo e(Session::get('nomor_induk')); ?></textarea>
          </div>
          <div class="mb-3">
            <button type="submit" class="btn btn-primary">SIMPAN</button>
          </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views//siswa/create.blade.php ENDPATH**/ ?>