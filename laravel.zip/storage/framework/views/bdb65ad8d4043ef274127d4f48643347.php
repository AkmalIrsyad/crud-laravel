<?php $__env->startSection('konten'); ?>
<form method="POST"action="<?php echo e('/siswa/'.$data->nomor_induk); ?>" enctype="multipart/form-data">
    
    
    <?php echo csrf_field(); ?>
    
    <?php echo method_field('PUT'); ?>
    <a href="/siswa" class="btn btn-secondary">Kembali</a>
    <div class="mb-3">
        <h4>Nomor NIK anda: <?php echo e($data->nomor_induk); ?></h4>
    </div>
          <div class="form-floating mb-3 ">
            <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" value="<?php echo e($data->nama); ?>" >
            <label for="nama">Nama</label>
          </div>
          <div class="mb-3">
            <label for="alamat">Alamat</label>
            <textarea class="form-control" name="alamat" ><?php echo e($data->alamat); ?></textarea>
          </div>
          <div class="mb-3">
            <?php if($data->foto): ?>
                <div class="mb-3">
                <img style="max-width:150px; max-height:150px" src="<?php echo e(url('foto').'/'. $data->foto); ?>"/>
                </div>
            <?php endif; ?>
            <label for="foto" class="form-label">Foto</label>
            <input class="form-control" type="file" naid="foto" name="foto">
          </div>
          <div class="mb-3">
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views/siswa/edit.blade.php ENDPATH**/ ?>