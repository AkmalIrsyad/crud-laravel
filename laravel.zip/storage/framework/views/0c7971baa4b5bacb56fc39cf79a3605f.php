<?php $__env->startSection('konten'); ?>

<a href="<?php echo e('/siswa/'); ?>" class="btn btn-secondary btn-sm">Kembali</a>

<div class="container mb-3">
    <h3><?php echo e($data->nama); ?></h3>
    <div class="mb-3">
      <p>NIK : <?php echo e($data->nomor_induk); ?> </p>
    </div>
    <div class="mb-3">
      <p>Alamat: <?php echo e($data->alamat); ?></p>
    </div>
    <div class="mb-3">
        <?php if($data->foto): ?>
                <div class="mb-3">
                Foto: <img style="max-width:150px; max-height:150px" src="<?php echo e(url('foto').'/'. $data->foto); ?>"/>
                </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL9\resources\views/siswa/show.blade.php ENDPATH**/ ?>